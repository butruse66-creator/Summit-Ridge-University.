# Summit Ridge University — Website Concept

A responsive, single-page university website concept built with HTML, CSS, and vanilla JavaScript.

## Included
- Responsive desktop and mobile layout
- Mobile navigation menu
- Searchable sample study-area cards
- Admissions call-to-action
- Enquiry form that prepares an email in the visitor's email app
- Telephone and WhatsApp links
- Contact details supplied for this project

## Contact details configured
- Phone: 0748 359 324
- WhatsApp: https://wa.me/256748359324
- Email: butrusfaith@gmail.com

## Preview locally
Open `index.html` in a modern browser. For the most reliable local preview, run a simple local web server from this folder.

## Important before publishing
**Summit Ridge University is a fictional website concept, not a claim that an accredited university exists under this name.** The study areas and admissions text are illustrative placeholders, not verified programs or admission requirements. Confirm the institution's real name, accreditation, program list, physical address, policies, and all official details before using this website publicly.

## Publishing
Upload the files in this folder to a static host such as GitHub Pages, Netlify, or another web host. No build step is required.

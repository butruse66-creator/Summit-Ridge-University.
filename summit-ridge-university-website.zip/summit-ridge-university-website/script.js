const menuToggle = document.querySelector('.menu-toggle');
const mainNav = document.querySelector('.main-nav');

if (menuToggle && mainNav) {
  menuToggle.addEventListener('click', () => {
    const isOpen = mainNav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(isOpen));
    menuToggle.setAttribute('aria-label', isOpen ? 'Close navigation' : 'Open navigation');
  });
  mainNav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    mainNav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
  }));
}

const searchInput = document.getElementById('program-search');
const programCards = [...document.querySelectorAll('.program-card')];
const programCount = document.getElementById('program-count');
const noResults = document.getElementById('no-results');

if (searchInput) {
  searchInput.addEventListener('input', () => {
    const query = searchInput.value.trim().toLowerCase();
    let visible = 0;
    programCards.forEach(card => {
      const matches = (card.dataset.search + ' ' + card.textContent).toLowerCase().includes(query);
      card.hidden = !matches;
      if (matches) visible++;
    });
    programCount.textContent = `${visible} ${visible === 1 ? 'study area' : 'study areas'}`;
    noResults.hidden = visible !== 0;
  });
}

const form = document.getElementById('enquiry-form');
if (form) {
  form.addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(form);
    const subject = encodeURIComponent(`Website enquiry: ${data.get('interest')}`);
    const body = encodeURIComponent(
      `Name: ${data.get('name')}\nEmail: ${data.get('email')}\nArea of interest: ${data.get('interest')}\n\nMessage:\n${data.get('message')}`
    );
    window.location.href = `mailto:butrusfaith@gmail.com?subject=${subject}&body=${body}`;
  });
}

document.getElementById('year').textContent = new Date().getFullYear();
